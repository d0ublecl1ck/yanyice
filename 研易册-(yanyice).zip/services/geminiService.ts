
import { GoogleGenAI, Type, GenerateContentResponse } from "@google/genai";

// 修正：根据规范，API Key 必须从 process.env.API_KEY 获取，不再通过参数传递
export const extractLiuYaoData = async (input: string | File) => {
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  
  const systemInstruction = `
    你是一个专业的六爻排盘助手。你的任务是从用户的文本描述或卦例图片中提取出结构化的六爻数据。
    
    六爻数据包括：
    1. 问事主题 (subject)
    2. 6个爻的状态 (lines): 0=少阳(—), 1=少阴(--), 2=老阳(— O), 3=老阴(-- X)。顺序必须是从下往上（初爻到上爻）。
    3. 月建 (monthBranch) 和 日辰 (dayBranch) 如：寅月 甲辰日。
    
    返回 JSON 格式。
  `;

  const schema = {
    type: Type.OBJECT,
    properties: {
      subject: { type: Type.STRING },
      lines: {
        type: Type.ARRAY,
        items: { type: Type.INTEGER },
        description: "从初爻到上爻的爻值 (0-3)",
      },
      monthBranch: { type: Type.STRING },
      dayBranch: { type: Type.STRING },
    },
    required: ["lines"]
  };

  try {
    let contents: any;
    if (typeof input === 'string') {
      contents = input;
    } else {
      const base64 = await fileToBase64(input);
      contents = {
        parts: [
          { inlineData: { data: base64, mimeType: input.type } },
          { text: "请从这张六爻排盘图中提取信息" }
        ]
      };
    }

    // 修正：使用 gemini-3-pro-preview 应对复杂的结构化提取任务，并正确处理响应
    const response: GenerateContentResponse = await ai.models.generateContent({
      model: 'gemini-3-pro-preview',
      contents,
      config: {
        systemInstruction,
        responseMimeType: "application/json",
        responseSchema: schema,
      }
    });

    return JSON.parse(response.text?.trim() || "{}");
  } catch (error) {
    console.error("Gemini AI extraction failed:", error);
    throw error;
  }
};

const fileToBase64 = (file: File): Promise<string> => {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.readAsDataURL(file);
    reader.onload = () => resolve((reader.result as string).split(',')[1]);
    reader.onerror = error => reject(error);
  });
};
